export {
  MdbInfiniteScrollDirective,
  MdbInfiniteScrollDirection,
} from './infinite-scroll.directive';
export { MdbInfiniteScrollModule } from './infinite-scroll.module';
