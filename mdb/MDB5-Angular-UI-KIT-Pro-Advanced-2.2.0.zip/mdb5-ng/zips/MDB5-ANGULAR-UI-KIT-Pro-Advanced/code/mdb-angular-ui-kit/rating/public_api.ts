export { MdbRatingComponent } from './rating.component';
export { MdbRatingModule } from './rating.module';
export { MdbRatingIconComponent } from './rating-icon.component';
