export { MdbRangeModule } from './range.module';
export { MdbRangeComponent } from './range.component';
